﻿using Házi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Házi
{
    public class Inputs
    {
        public string Name { get; set; }
        public double Weight { get; set; }
        public string Exercise { get; set; }
        public double ExerciseLength { get; set; }
    }
}