﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Házi.Models
{
    public class Outputs
    {
        public string Name { get; set; }
        public double Weight { get; set; }
        public double ExerciseLength { get; set; }
        public double BurntCalories { get; set; }
    }
}